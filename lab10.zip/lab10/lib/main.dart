import 'package:flutter/material.dart';

//Task 1 & 2
// void main() {
//   runApp(NavigationApp());
// }

// class NavigationApp extends StatelessWidget {
//   const NavigationApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: FirstPage(),
//     );
//   }
// }

// class FirstPage extends StatelessWidget {
//   const FirstPage({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text("First Screeen "),),
//       body: Center(
//   child: Column(
//     mainAxisAlignment: MainAxisAlignment.center,
//     children: [
//       GestureDetector(
//         onTap: () {
//           Navigator.push(
//             context,
//             MaterialPageRoute(builder: (_) => SecondPage()),
//           );
//         },
//         child: Hero(
//   tag: 'cat',
//   child: Image.network(
//     'https://i.ytimg.com/vi/feEMKVcFyC4/hq720.jpg',
//     width: 120,
//     height: 120,
//     fit: BoxFit.cover,
//   ),
// )
//       ),
//       Text("Tap image for Hero animation"),
//     ],
//   ),
// ),
//     );
//   }
// }


// class SecondPage extends StatelessWidget {
//   const SecondPage({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text("Secound Screeen "),),
//       body: Center(
//         child: Column(
//           children: [
//             Hero(tag: 'cat', child: Image.network(
//               'https://i.ytimg.com/vi/feEMKVcFyC4/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLCRnp5fFToaizxzl2wu9G78jacEjw'
//             ,width: 300,
//             height: 300,
//             ),
//             ),
//              ElevatedButton(
//               onPressed: () {
//                 Navigator.pop(context);
//               },
//               child: Text("Go Back"),
//             ),
//           ],
//         ),
//         ),
//       );
    
//   }
// }

void main(){
  runApp(TODO());
}

class TODO extends StatelessWidget {
  const TODO({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home:FirstPage(
      todos: List.generate(20,
       (i) => Todo(
        'Todo $i',
        'Description of Todo number $i',
       )
       )
      ),
    );
  }
}

class Todo {
  final String title;
  final String description;

  Todo(this.title, this.description);
}

class FirstPage extends StatelessWidget {
  final List<Todo> todos;

  const FirstPage({super.key,required this.todos});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("First Page of TODO"),),
      body: ListView.builder(
        itemCount: todos.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Icon(Icons.task),
            title: Text(todos[index].title),
            subtitle: Text("Tap to view Detail"),

            onTap: () {
              Navigator.push(context,
              MaterialPageRoute(builder: (context)=> DetailScreen(todo :todos[index])));
            }
          );
        }
        )
    );
  }
}

class DetailScreen extends StatelessWidget {
  final Todo todo;
  const DetailScreen({super.key,required this.todo});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        title: Text(todo.title),
      ),
      body: Padding(padding: EdgeInsets.all(20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            todo.title,
            style: TextStyle(fontSize: 24,fontWeight: FontWeight.bold),

          ),
          SizedBox(height: 20),
            Text(
              todo.description,
              style: TextStyle(fontSize: 18),
            ),
            ElevatedButton(onPressed: () {
              Navigator.pop(context);
            }, child: Text("Go back"))
        ],
      ),
      ),
    );
  }
}

